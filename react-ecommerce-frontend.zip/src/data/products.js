export default [
  {id:1, name:'Running Shoes', price:2499, image:'https://images.unsplash.com/photo-1528701800489-476f3f6bd5a7?w=800&q=60'},
  {id:2, name:'Wireless Headphones', price:3999, image:'https://images.unsplash.com/photo-1511367461989-f85a21fda167?w=800&q=60'},
  {id:3, name:'Leather Bag', price:2999, image:'https://images.unsplash.com/photo-1520975912080-2c8a3b3c6f1f?w=800&q=60'},
  {id:4, name:'Smart Watch', price:6999, image:'https://images.unsplash.com/photo-1516574187841-cb9cc2ca948b?w=800&q=60'},
  {id:5, name:'Sunglasses', price:1499, image:'https://images.unsplash.com/photo-1519681393784-d120267933ba?w=800&q=60'},
  {id:6, name:'Backpack', price:1999, image:'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800&q=60'}
]
